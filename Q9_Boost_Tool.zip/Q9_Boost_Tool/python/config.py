# config/config.py

tkn = "MTM2Mjc4NjM0MzM4MTYzNTA5Mg.GkUHu-.f2tW9Kuc9f7bIUu2J1bqnCsfpcirJfM_2aIoPE"
secret = "E8y1XCGRUUO8_u1IxSDPZQzwZiZmF_TN"
client_id = "1362786343381635092"
redirect = "http://localhost:8080"